//
//  HTMLSample3ViewController.h
//  HTMLSample3
//
//  Created by 溝田 隆明 on 11/02/14.
//  Copyright 2011 conol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HTMLSample3ViewController : UIViewController<UIWebViewDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate> {
    
    IBOutlet UIWebView *webview;
}
@property(nonatomic, retain) IBOutlet UIWebView *webView;
@property(nonatomic, retain) NSString *path;

+ (id)controllerWithResourcePath:(NSString *)path;
+ (id)controllerWithResourcePath:(NSString *)path nibNamed:(NSString *)nib bundle:(NSBundle *)bundle;
- (id)initWithResourcePath:(NSString *)path nibNamed:(NSString *)nib bundle:(NSBundle *)bundle;

@end
