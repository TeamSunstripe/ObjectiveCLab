//
//  HTMLSample3AppDelegate.h
//  HTMLSample3
//
//  Created by 溝田 隆明 on 11/02/14.
//  Copyright 2011 conol. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HTMLSample3ViewController;

@interface HTMLSample3AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet HTMLSample3ViewController *viewController;

@end
