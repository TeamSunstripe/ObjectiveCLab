//
//  HTMLSample3ViewController.m
//  HTMLSample3
//
//  Created by 溝田 隆明 on 11/02/14.
//  Copyright 2011 conol. All rights reserved.
//

#import "HTMLSample3ViewController.h"
#define DEFAULT_HTML @"html/index.html"

@interface HTMLSample3ViewController()
- (void)handleActionURL:(NSURL *)url;
@end

@implementation HTMLSample3ViewController

+ (id)controllerWithResourcePath:(NSString *)path {
    return [[self class] controllerWithResourcePath:path nibNamed:nil bundle:nil];
}

+ (id)controllerWithResourcePath:(NSString *)path nibNamed:(NSString *)nib bundle:(NSBundle *)bundle {
    return [[[HTMLSample3ViewController alloc] initWithResourcePath:path nibNamed:nib bundle:bundle] autorelease];
}

- (id)initWithResourcePath:(NSString *)path nibNamed:(NSString *) nib bundle:(NSBundle *)bundle {
    if ((self = [super initWithNibName:nib bundle:bundle])) {
        self.path = path;
    }
    return self;
}

@synthesize webView=webView_;
@synthesize path=path_;

- (void)dealloc
{
    [webview release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if (self.webView == nil) {
        self.webView = [[[UIWebView alloc] initWithFrame:self.view.bounds] autorelease];
        [self.view addSubview:self.webView];
    }
    NSString *path = self.path;
    if ([path length] == 0) {
        path = DEFAULT_HTML;
    }
    NSString *ext = [path pathExtension];
    self.webView.delegate = self;
    NSURL *url = [[NSBundle mainBundle] URLForResource:[path stringByDeletingPathExtension] withExtension:ext];
    [self.webView loadRequest:[NSURLRequest requestWithURL:url]];
}

#pragma mark UIWebViewDelegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    NSURL *url = [request URL];
    if ([[url scheme] isEqual:@"action"]) {
        [self handleActionURL:url];
        return NO;
    }
    return YES;
}
#pragma mark HTML Integration
- (void)handleActionURL:(NSURL *)url {
    SEL action = NSSelectorFromString([NSString stringWithFormat:@"%@Action:", [url host]]);
    if ([self respondsToSelector:action]) {
        [self performSelector:action withObject:url];
        return;
    }
    action = NSSelectorFromString([NSString stringWithFormat:@"%@Action", [url host]]);
    if ([self respondsToSelector:action]) {
        [self performSelector:action];
        return;
    }
    NSLog(@"unknown action: %@", url);
}

-(void)cameraAction {
    if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
        return;
    }
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    picker.delegate = self;
    picker.allowsEditing = YES;
    [self presentModalViewController:picker animated:YES];
    [picker release];
}

- (void)viewDidUnload
{
    [webview release];
    webview = nil;
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
