//
//  HTMLSample3Tests.m
//  HTMLSample3Tests
//
//  Created by 溝田 隆明 on 11/02/14.
//  Copyright 2011 conol. All rights reserved.
//

#import "HTMLSample3Tests.h"


@implementation HTMLSample3Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in HTMLSample3Tests");
}

@end
