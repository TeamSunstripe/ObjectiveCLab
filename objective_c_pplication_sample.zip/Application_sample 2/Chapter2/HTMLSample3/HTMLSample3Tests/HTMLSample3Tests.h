//
//  HTMLSample3Tests.h
//  HTMLSample3Tests
//
//  Created by 溝田 隆明 on 11/02/14.
//  Copyright 2011 conol. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface HTMLSample3Tests : SenTestCase {
@private
    
}

@end
