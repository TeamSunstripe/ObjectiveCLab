//
//  HTMLSample2Tests.h
//  HTMLSample2Tests
//
//  Created by 溝田 隆明 on 11/02/15.
//  Copyright 2011 conol. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface HTMLSample2Tests : SenTestCase {
@private
    
}

@end
