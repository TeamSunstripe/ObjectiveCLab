//
//  HTMLSample2Tests.m
//  HTMLSample2Tests
//
//  Created by 溝田 隆明 on 11/02/15.
//  Copyright 2011 conol. All rights reserved.
//

#import "HTMLSample2Tests.h"


@implementation HTMLSample2Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in HTMLSample2Tests");
}

@end
