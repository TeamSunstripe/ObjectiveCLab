//
//  HTMLSample2AppDelegate.m
//  HTMLSample2
//
//  Created by 溝田 隆明 on 11/02/15.
//  Copyright 2011 conol. All rights reserved.
//

#import "HTMLSample2AppDelegate.h"
#import "HTMLSample2ViewController.h"

@implementation HTMLSample2AppDelegate


@synthesize window;
@synthesize naviController;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [self.window addSubview:naviController.view];
    [self.window makeKeyAndVisible];
    return YES;
}

- (void)dealloc
{
    [window release];
    [naviController release];
    [super dealloc];
}

@end
