//
//  HTMLSample2ViewController.h
//  HTMLSample2
//
//  Created by 溝田 隆明 on 11/02/15.
//  Copyright 2011 conol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HTMLSample2ViewController : UIViewController {
    UIWebView *_webview;
    NSString *_path;
}

@property (nonatomic, retain) IBOutlet UIWebView *webview;
@property (nonatomic, copy) NSString *path;

+(id)controllerWithResourcePath:(NSString *)path;
+(id)controllerWithResourcePath:(NSString *)path nibNamed:(NSString *)nib bundle:(NSBundle *)bundle;
-(id)initWithResourcePath: (NSString *)path nibNamed:(NSString *) nib bundle:(NSBundle *)bundle;

@end
