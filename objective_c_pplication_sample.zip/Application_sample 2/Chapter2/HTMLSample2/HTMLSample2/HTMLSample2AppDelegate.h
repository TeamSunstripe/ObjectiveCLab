//
//  HTMLSample2AppDelegate.h
//  HTMLSample2
//
//  Created by 溝田 隆明 on 11/02/15.
//  Copyright 2011 conol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HTMLSample2AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	UINavigationController *naviController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *naviController;

@end
