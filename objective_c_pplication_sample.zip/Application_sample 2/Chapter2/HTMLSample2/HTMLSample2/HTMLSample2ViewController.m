//
//  HTMLSample2ViewController.m
//  HTMLSample2
//
//  Created by 溝田 隆明 on 11/02/15.
//  Copyright 2011 conol. All rights reserved.
//

#import "HTMLSample2ViewController.h"

#define DEFAULT_HTML @"html/index.html"

@implementation HTMLSample2ViewController

+(id)controllerWithResourcePath:(NSString *)path {
    return [[self class] controllerWithResourcePath:path nibNamed:nil bundle:nil];
}

+ (id)controllerWithResourcePath:(NSString *)path nibNamed:(NSString *)nib bundle:(NSBundle *)bundle {
    return [[[HTMLSample2ViewController alloc] initWithResourcePath:path nibNamed:nib bundle:bundle] autorelease];
}

@synthesize webview = webview_;
@synthesize path = path_;

-(id)initWithResourcePath: (NSString *)path nibNamed:(NSString *) nib bundle:(NSBundle *)bundle {
    if ((self = [super initWithNibName:nib bundle:bundle])) {
        self.path = path;
    }
    return self;
}

- (void)viewDidLoad {
    NSString *path = self.path;
    if ([path length] == 0) {
        path = DEFAULT_HTML;
    }
    self.navigationItem.title = path;
    NSString *ext = [path pathExtension];
    NSURL *url = [[NSBundle mainBundle] URLForResource:[path stringByDeletingPathExtension] withExtension:ext];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.webview loadRequest:request];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest: (NSURLRequest *)request navigationType:(UIWebViewNavigationType) navigationType {
    if(navigationType == UIWebViewNavigationTypeLinkClicked){
        NSString *clickLink = [[request URL] absoluteString];
        NSArray *sepalate = [clickLink componentsSeparatedByString:@"/"];
        int cnt = [sepalate count];
        HTMLSample2ViewController *jump = [[self class] controllerWithResourcePath:[NSString stringWithFormat:@"html/%@",[sepalate objectAtIndex:cnt-1]]];
        [self.navigationController pushViewController:jump animated:YES];
        return NO;
    }
    return YES;
}

- (void)viewDidUnload {
    self.webview = nil;
    [super viewDidUnload];
}
- (void)dealloc {
    self.path = nil;
    self.webview = nil;
    [super dealloc];
}

@end