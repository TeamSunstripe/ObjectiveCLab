//
//  HTMLSample1Tests.h
//  HTMLSample1Tests
//
//  Created by 溝田 隆明 on 11/02/16.
//  Copyright 2011 conol. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface HTMLSample1Tests : SenTestCase {
@private
    
}

@end
