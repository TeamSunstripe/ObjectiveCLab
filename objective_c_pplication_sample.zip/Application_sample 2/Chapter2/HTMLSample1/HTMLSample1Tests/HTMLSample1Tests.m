//
//  HTMLSample1Tests.m
//  HTMLSample1Tests
//
//  Created by 溝田 隆明 on 11/02/16.
//  Copyright 2011 conol. All rights reserved.
//

#import "HTMLSample1Tests.h"


@implementation HTMLSample1Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in HTMLSample1Tests");
}

@end
