//
//  HTMLSample1AppDelegate.h
//  HTMLSample1
//
//  Created by 溝田 隆明 on 11/02/16.
//  Copyright 2011 conol. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HTMLSample1ViewController;

@interface HTMLSample1AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet HTMLSample1ViewController *viewController;

@end
