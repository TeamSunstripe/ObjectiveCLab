//
//  HTMLSample1ViewController.m
//  HTMLSample1
//
//  Created by 溝田 隆明 on 11/02/16.
//  Copyright 2011 conol. All rights reserved.
//

#import "HTMLSample1ViewController.h"

@implementation HTMLSample1ViewController
@synthesize webview = _webview;

- (void)dealloc
{
    [_webview release];
    self.webview = nil;
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewDidLoad
{
    NSString *path = @"html/index.html";
    NSString *ext = [path pathExtension];
    NSURL *url = [[NSBundle mainBundle] URLForResource:[path stringByDeletingPathExtension] withExtension:ext];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.webview loadRequest:request];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType) navigationType {
    if(navigationType == UIWebViewNavigationTypeLinkClicked){
        [self.webview stringByEvaluatingJavaScriptFromString:@"move()"];
        return NO;
    }
    return YES;
}

- (void)viewDidUnload
{
    self.webview = nil;
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
