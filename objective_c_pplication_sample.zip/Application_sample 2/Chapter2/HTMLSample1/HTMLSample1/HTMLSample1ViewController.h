//
//  HTMLSample1ViewController.h
//  HTMLSample1
//
//  Created by 溝田 隆明 on 11/02/16.
//  Copyright 2011 conol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HTMLSample1ViewController : UIViewController<UIWebViewDelegate> {
    
    UIWebView *_webview;
}
@property (nonatomic, retain) IBOutlet UIWebView *webview;

@end
