//
//  CSSList.m
//  CSSSample
//
//  Created by 溝田 隆明 on 11/04/14.
//  Copyright 2011 conol. All rights reserved.
//

#import "CSSList.h"
#import "CSSSampleViewController.h"


@implementation CSSList

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    samples = [[self dataLoad:@"samples.plist"] retain];
}

-(NSArray *) dataLoad:(NSString *) path {
	NSString *FilePath		= [[NSBundle mainBundle] pathForResource:path ofType:nil];
    NSArray *datas;
    if([[NSFileManager defaultManager] fileExistsAtPath:FilePath]){
        datas	= [NSArray arrayWithContentsOfFile:FilePath];
    }
	return datas ? datas : nil;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [samples count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    cell.textLabel.text	= [[samples objectAtIndex:indexPath.row] objectForKey:@"name"];
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    CSSSampleViewController *detailViewController = [[CSSSampleViewController alloc] initWithNibName:@"CSSSampleViewController" bundle:nil];
    detailViewController.filename = [[samples objectAtIndex:indexPath.row] objectForKey:@"path"];
    [self.navigationController pushViewController:detailViewController animated:YES];
    [detailViewController release];
}

@end
