//
//  CSSSampleAppDelegate.h
//  CSSSample
//
//  Created by 溝田 隆明 on 11/04/14.
//  Copyright 2011 conol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CSSSampleAppDelegate : NSObject <UIApplicationDelegate> {
    IBOutlet UINavigationController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *viewController;

@end
