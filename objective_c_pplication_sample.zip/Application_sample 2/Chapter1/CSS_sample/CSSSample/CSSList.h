//
//  CSSList.h
//  CSSSample
//
//  Created by 溝田 隆明 on 11/04/14.
//  Copyright 2011 conol. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CSSList : UITableViewController {
    NSArray *samples;
}

-(NSArray *) dataLoad:(NSString *) path;

@end
