//
//  CSSSampleViewController.m
//  CSSSample
//
//  Created by 溝田 隆明 on 11/02/14.
//  Copyright 2011 conol. All rights reserved.
//

#import "CSSSampleViewController.h"

@implementation CSSSampleViewController

@synthesize filename;

- (void)dealloc
{
    [webview release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSString *path = [NSString stringWithFormat:@"html/%@",filename];
    NSString *ext = [path pathExtension];
    NSURL *url = [[NSBundle mainBundle] URLForResource:[path stringByDeletingPathExtension] withExtension:ext];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [webview loadRequest:request];
}


- (void)viewDidUnload
{
    [webview release];
    webview = nil;
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
