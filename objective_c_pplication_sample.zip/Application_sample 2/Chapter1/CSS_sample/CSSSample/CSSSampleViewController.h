//
//  CSSSampleViewController.h
//  CSSSample
//
//  Created by 溝田 隆明 on 11/04/14.
//  Copyright 2011 conol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CSSSampleViewController : UIViewController {
    
    IBOutlet UIWebView *webview;
    NSString *filename;
}

@property(nonatomic, copy) NSString *filename;

@end
