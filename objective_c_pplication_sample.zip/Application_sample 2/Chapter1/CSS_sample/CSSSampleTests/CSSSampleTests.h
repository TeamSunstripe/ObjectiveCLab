//
//  CSSSampleTests.h
//  CSSSampleTests
//
//  Created by 溝田 隆明 on 11/04/14.
//  Copyright 2011 conol. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface CSSSampleTests : SenTestCase {
@private
    
}

@end
