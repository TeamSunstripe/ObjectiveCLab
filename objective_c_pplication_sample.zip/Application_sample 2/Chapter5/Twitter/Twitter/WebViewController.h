//
//  WebViewController.h
//  Twitter
//
//  Created by Yosuke Suzuki on 11/02/08.
//  Copyright 2011 バスケ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HTMLViewController.h"


@interface WebViewController : HTMLViewController {
    
}

@property(nonatomic, retain) NSURL *url;

- (IBAction)goBack:(id)sender;
- (IBAction)goNext:(id)sender;
- (IBAction)reload:(id)sender;

@end
