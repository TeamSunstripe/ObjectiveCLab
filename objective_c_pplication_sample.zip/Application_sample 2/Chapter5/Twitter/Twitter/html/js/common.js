function startup() {
	runAction("log", "loaded");
	runAction('pageLoaded', '?' + encodeURIComponent(window.location.href));
}

/* HTMLViewControllerのメソッドを呼び出す */
function runAction(action, params) {
	if (!params) params = '';
	
	if (params.length > 0 && params.substr(0, 1) != '/') {
		params = '/' + params;
	}
	
	window.location.href = "action://" + action + params;
}

// ハッシュタグ用の正規表現
var hash_regex = /#([a-z0-9_]+)/gi;
var hash_link = '<a class="hashtag" href="twitter://search?q=%23$1">#$1</a>';

// URLを展開
var url_regex = new RegExp('(https?://[-_.!~*\'()a-zA-Z0-9;/?:@&=+$,%#]+)', 'gi');
var url_link = '<a class="link" href="$1">$1</a>';

// @ユーザー用の正規表現
var at_user_regex = /@([a-z0-9_]+)/gi;
var at_user_link = '<a class="atUser" href="twitter+open://rest/users/show?screen_name=$1">@$1</a>';

function activateLinks(text) {
	return text
			.replace(hash_regex, hash_link)
			.replace(at_user_regex, at_user_link)
			.replace(url_regex, url_link);
}

// HTMLのエスケープを行う
function h(val) {
	return $("<div></div>").text(val).html();
}

// ユーザー名へのリンクに変更する
function userLink(screen_name) {
	return at_user_link.replace(/@?\$1/g, screen_name);
}

var append = false;

// 結果を表示する
function displayResult(result) {
	if (!window.append) {
		$('#result').empty();
	}
	
	result.appendTo("#result");
	$('body').animate({ scrollTop: 0 }, 'slow');
}

