//
//  main.m
//  Twitter
//
//  Created by Yosuke Suzuki on 11/02/07.
//  Copyright 2011 バスケ. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	int retVal = UIApplicationMain(argc, argv, nil, nil);
	[pool release];
	return retVal;
}
