//
//  TwitterAPI.h
//  Twitter
//
//  Created by Yosuke Suzuki on 11/02/08.
//  Copyright 2011 バスケ. All rights reserved.
//

#import "ASIHTTPRequest.h"

#import <Foundation/Foundation.h>

#define TWITTER_REST_API  @"http://api.twitter.com/1"
#define TWITTER_SEARCH_API @"http://search.twitter.com/search.json"

@interface TwitterRequest : ASIHTTPRequest {
    
}

+ (TwitterRequest *)requestWithParams:(NSURL *)params;

+ (TwitterRequest *)searchRequestWithParams:(NSDictionary *)params;
+ (TwitterRequest *)searchRequestWithQuery:(NSString *)query;

@property(nonatomic, retain, readwrite) NSString *callback;

+ (NSString *)queryString:(NSDictionary *)params;

@end
