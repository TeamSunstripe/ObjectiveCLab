//
//  TwitterAppDelegate.h
//  Twitter
//
//  Created by Yosuke Suzuki on 11/02/07.
//  Copyright 2011 バスケ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TwitterViewController.h"

@interface TwitterAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@property (nonatomic, retain) IBOutlet TwitterViewController *topTwitterViewController;

@end
