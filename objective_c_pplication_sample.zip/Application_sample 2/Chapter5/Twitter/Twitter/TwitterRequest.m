//
//  TwitterAPI.m
//  Twitter
//
//  Created by Yosuke Suzuki on 11/02/08.
//  Copyright 2011 バスケ. All rights reserved.
//

#import "TwitterRequest.h"


@implementation TwitterRequest

@synthesize callback=_callback;

#pragma mark Twitter APIリクエストの生成

+ (TwitterRequest *)requestWithParams:(NSURL *)params {
	NSString *url = [NSString stringWithFormat:@"%@%@.json?%@", TWITTER_REST_API, [params path], [params query]];
	
	TwitterRequest *request = [self requestWithURL:[NSURL URLWithString:url]];
	
	NSArray *components = [[params path] pathComponents];
	request.callback = [[components objectAtIndex:1] stringByAppendingString:@"Callback"];
	
	return request;
}

+ (TwitterRequest *)searchRequestWithParams:(NSDictionary *)params {
	return [self searchRequestWithQuery:[self queryString:params]];
}

+ (TwitterRequest *)searchRequestWithQuery:(NSString *)query {
	NSString *url = [NSString stringWithFormat:@"%@?%@", TWITTER_SEARCH_API, query];
	
	TwitterRequest *request = [self requestWithURL:[NSURL URLWithString:url]];
	request.callback = @"searchCallback";
	
	return request;
}

- (void)dealloc {
	self.callback = nil;
	
	[super dealloc];
}

/*
 辞書からURLのqueryに使える文字列に変換する
 */
+ (NSString *)queryString:(NSDictionary *)params {
	NSMutableString *buf = [NSMutableString stringWithCapacity:100];
	BOOL addSeparator = NO;
	
	for (NSString *name in params) {
		if (addSeparator) {
			[buf appendString:@"&"];
		} else {
			addSeparator = YES;
		}
		
		[buf appendString:name];
		[buf appendString:@"="];
		
		NSString *value = [params objectForKey:name];
		[buf appendString:[value stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
	}
	
	return [NSString stringWithString:buf];
}

@end
