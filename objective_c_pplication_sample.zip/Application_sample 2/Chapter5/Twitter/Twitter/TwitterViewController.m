//
//  RootViewController.m
//  Twitter
//
//  Created by Yosuke Suzuki on 11/02/07.
//  Copyright 2011 バスケ. All rights reserved.
//

#import "TwitterViewController.h"
#import "WebViewController.h"
#import "TwitterRequest.h"

#import "JSON.h"

@interface TwitterViewController()<UISearchBarDelegate>

@property(nonatomic, retain, readwrite) NSMutableArray *requests;

- (void)pushTwitterViewController:(NSURL *)params;
- (void)twitterRequest:(NSURL *)params;

@end

@implementation TwitterViewController

@synthesize initialRequest=_initialRequest;
@synthesize requests=_requests;

- (void)dealloc {
    [searchBar release];
	
	self.initialRequest = nil;
	
	for (TwitterRequest *request in self.requests) {
		[request clearDelegatesAndCancel];
	}
	self.requests = nil;
	
    [super dealloc];
}
#pragma mark �r���[�̊Ǘ�

- (void)viewDidLoad {
	[super viewDidLoad];
	
	if (!self.title) {
		self.title = @"Twitter";
	}
	
	self.requests = [NSMutableArray arrayWithCapacity:5];
	
	self.webView.backgroundColor = [UIColor clearColor];
	self.webView.opaque = NO;
}

- (void)viewDidUnload {
	[searchBar release];
	searchBar = nil;
	
	self.initialRequest = nil;
	
	for (TwitterRequest *request in self.requests) {
		[request clearDelegatesAndCancel];
	}
	self.requests = nil;
	
	[super viewDidUnload];
}

#pragma mark UIWebViewDelegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
	
	// super�N���X���_�����ƌ�������_��
	if (![super webView:webView shouldStartLoadWithRequest:request navigationType:navigationType]) return NO;
	
	// ���[�J����HTML�̓I�b�P�[
	NSString *scheme = [[request URL] scheme];
	if ([scheme isEqual:@"file"]) {
		return YES;
	}
	
	// Twitter API��p�X�L�[�}���n���h�����O
	if ([scheme isEqual:@"twitter"]) {
		[self twitterRequest:[request URL]];
		return NO;
	}
	
	if ([scheme isEqual:@"twitter+open"]) {
		[self pushTwitterViewController:[request URL]];
		return NO;
	}
	
	// ����ȊO�́A�ʂ̉�ʂ�����ăv�b�V��
	WebViewController *controller = [[WebViewController alloc] init];
	controller.url = [request URL];
	[self.navigationController pushViewController:controller animated:YES];
	[controller release];
	
	return NO;
}

- (void)pushTwitterViewController:(NSURL *)params {
	TwitterViewController *controller = [[TwitterViewController alloc] initWithNibName:nil bundle:nil];
	controller.initialRequest = params;
	
	[self.navigationController pushViewController:controller animated:YES];
	[controller release];
}

- (void)pageLoadedAction:(NSURL *)url {
	if (self.initialRequest) {
		[self twitterRequest:self.initialRequest];
		self.initialRequest = nil;
	}
}

#pragma mark UISearchBarDelegate

- (void)searchBarSearchButtonClicked:(UISearchBar *)aSearchBar {
	NSDictionary *query = [NSDictionary dictionaryWithObject:aSearchBar.text forKey:@"q"];
	NSString *queryString = [TwitterRequest queryString:query];
	
	NSURL *params = [NSURL URLWithString:[NSString stringWithFormat:@"twitter://search?%@", queryString]];
	[self pushTwitterViewController:params];
}

#pragma mark Twitter API�Ăяo��

- (void)twitterRequest:(NSURL *)params {
	TwitterRequest *request;
	
	if ([[params host] isEqual:@"rest"]) {
		request = [TwitterRequest requestWithParams:params];
	} else {
		request = [TwitterRequest searchRequestWithQuery:[params query]];
	}
	
	request.delegate = self;
	[request startAsynchronous];
	
	[self.requests addObject:request];
}

- (void)requestFinished:(TwitterRequest *)request {
	NSString *response = [request responseString];
	NSLog(@"Success: %@", [response JSONValue]);
	
	NSString *script = [NSString stringWithFormat:@"%@(%@)", request.callback, response];
	[self.webView stringByEvaluatingJavaScriptFromString:script];
	
	[self.requests removeObject:request];
}

- (void)requestFailed:(TwitterRequest *)request {
	NSLog(@"Fail: %@", request); // TODO: �����ƃG���[�������������邱��
	
	[self.requests removeObject:request];
}

@end
