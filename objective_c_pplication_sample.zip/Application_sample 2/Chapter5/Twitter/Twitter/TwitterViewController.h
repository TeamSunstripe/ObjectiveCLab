//
//  RootViewController.h
//  Twitter
//
//  Created by Yosuke Suzuki on 11/02/07.
//  Copyright 2011 バスケ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HTMLViewController.h"

@interface TwitterViewController : HTMLViewController {

	IBOutlet UISearchBar *searchBar;
}

@property(nonatomic, retain, readwrite) NSURL *initialRequest;

@end
