//
//  WebPhotoViewerViewController.m
//  WebPhotoViewer
//
//  Created by Yosuke Suzuki on 10/11/29.
//  Copyright 2010 バスケ. All rights reserved.
//

#import "HTMLViewController.h"

#define DEFAULT_HTML @"html/index.html"



@interface HTMLViewController()

- (void)handleActionURL:(NSURL *)url;

@end


@implementation HTMLViewController

+ (id)controllerWithResourcePath:(NSString *)path {
	return [[self class] controllerWithResourcePath:path nibNamed:nil bundle:nil];
}

+ (id)controllerWithResourcePath:(NSString *)path nibNamed:(NSString *)nib bundle:(NSBundle *)bundle {
	return [[[HTMLViewController alloc] initWithResourcePath:path nibNamed:nib bundle:bundle] autorelease];
}


@synthesize webView=webView_;
@synthesize path=path_;


- (id)initWithResourcePath:(NSString *)path nibNamed:(NSString *)nib bundle:(NSBundle *)bundle {
	self = [super initWithNibName:nib bundle:bundle];
	if (self) {
		self.path = path;
	}
	
	return self;
}

			 
- (void)viewDidLoad {
    [super viewDidLoad];
	
	if (self.webView == nil) {
		self.webView = [[[UIWebView alloc] initWithFrame:self.view.bounds] autorelease];
		self.webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		[self.view addSubview:self.webView];
	}
	
	self.webView.delegate = self;
	
	[self loadInitialContents];
}

- (void)loadInitialContents {
	NSString *path = self.path;
	if ([path length] == 0) {
		path = DEFAULT_HTML;
	}
	
	NSString *ext = [path pathExtension];
	
	NSURL *url = [[NSBundle mainBundle] URLForResource:[path stringByDeletingPathExtension] withExtension:ext];
	[self.webView loadRequest:[NSURLRequest requestWithURL:url]];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}

- (void)viewDidUnload {
	self.webView = nil;
	
	[super viewDidUnload];
}


- (void)dealloc {
	self.path = nil;
	self.webView = nil;
	
    [super dealloc];
}

#pragma mark HTML Integration

- (void)pageLoaded:(NSString *)url {
	NSLog(@"page loaded: %@", url);
}

- (void)handleActionURL:(NSURL *)url {
	SEL action = NSSelectorFromString([NSString stringWithFormat:@"%@Action:", [url host]]);
	if ([self respondsToSelector:action]) {
		[self performSelector:action withObject:url];
		return;
	}
	
	action = NSSelectorFromString([NSString stringWithFormat:@"%@Action", [url host]]);
	if ([self respondsToSelector:action]) {
		[self performSelector:action];
		return;
	}
	
	NSLog(@"unknown action: %@", url);
}

- (void)pageLoadedAction:(NSURL *)url {
	NSString *pageUrl = [[url query] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	
	[self pageLoaded:pageUrl];
}

/* sample action */
- (void)logAction:(NSURL *)url {
	NSLog(@"%@ %@ %@", [url path], [url query], [url fragment]);
}

#pragma mark UIWebViewDelegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
	NSURL *url = [request URL];
	
	if ([[url scheme] isEqual:@"action"]) {
		[self handleActionURL:url];
		return NO;
	}
	
	return YES;
}

- (void)webViewDidStartLoad:(UIWebView *)webView {
	
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
	
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
	
}

@end
