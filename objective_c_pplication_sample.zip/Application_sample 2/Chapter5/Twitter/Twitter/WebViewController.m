//
//  WebViewController.m
//  Twitter
//
//  Created by Yosuke Suzuki on 11/02/08.
//  Copyright 2011 バスケ. All rights reserved.
//

#import "WebViewController.h"


@implementation WebViewController

@synthesize url=url_;

- (void)dealloc {
	self.url = nil;
	
	[super dealloc];
}

#pragma mark - View lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
	
}

- (void)loadInitialContents {
	if (self.url) {
		[self.webView loadRequest:[NSURLRequest requestWithURL:self.url]];
	}
}

#pragma mark - アクション

- (IBAction)goBack:(id)sender {
	[self.webView goBack];
}

- (IBAction)goNext:(id)sender {
	[self.webView goForward];
}

- (IBAction)reload:(id)sender {
	[self.webView reload];
}

@end
