/**
 * @author os
 */

function load(){
	//prevent window scroll
	document.body.addEventListener("touchmove",function(e){e.preventDefault();},false);
	
	//start loading data
	dataController.init();
		
	//setup photos
    imageViewController.init();
		
	//setup interface
	interfaceController.init();
}

var orientationChangeDispatcher = {
	funcArray:[],
	
	dispatchChange:function(i){
		for (var i=0;i<this.funcArray.length;i++){
			this.funcArray[i]();
		}
	},
	
	addEventListener:function(typ,func){
		this.funcArray.push(func);
	}
}

var dataController = {

    _listArray:[],
    
    init:function(){
		this._listArray[0] = {id:0,src:"photo/01.jpg",tmb:"photo/01_tmb.jpg"};
		this._listArray[1] = {id:1,src:"photo/02.jpg",tmb:"photo/02_tmb.jpg"};
		this._listArray[2] = {id:2,src:"photo/03.jpg",tmb:"photo/03_tmb.jpg"};
		this._listArray[3] = {id:3,src:"photo/04.jpg",tmb:"photo/04_tmb.jpg"};
		this._listArray[4] = {id:4,src:"photo/05.jpg",tmb:"photo/05_tmb.jpg"};
		this._listArray[5] = {id:5,src:"photo/06.jpg",tmb:"photo/06_tmb.jpg"};
		this._listArray[6] = {id:6,src:"photo/07.jpg",tmb:"photo/07_tmb.jpg"};
		this._listArray[7] = {id:7,src:"photo/08.jpg",tmb:"photo/08_tmb.jpg"};
		this._listArray[8] = {id:8,src:"photo/09.jpg",tmb:"photo/09_tmb.jpg"};
	},
	
    getImages:function(){
        return this._listArray;
    },
    
    getLength:function(){
        return this._listArray.length;
    },
    
    getImage:function(n){
        return this._listArray[n];
    }
}

var imageViewController = {

    init: function(){
		
		//setup stacklayout
		this.stackLayout = CreateStackLayout("container",[]);
			
        this.max_page = dataController.getLength()-1;
        this.element = document.getElementById('container');
        
		
		//photo��z�u
		this.photo0 = new Photo("photo0","photoView0",11);
		this.photo1 = new Photo("photo1","photoView1",12);
				
        //�g�����W�V�������`
        this.dissolve_trans = new Transition(Transition.DISSOLVE_TYPE,0.4,Transition.LINEAR_TIMING);
		this.push_trans = new Transition(Transition.PUSH_TYPE,0.4,Transition.EASE_OUT_TIMING);
        this.ct = 0;
        this.page = 0;
        
        //�ŏ��̃y�[�W��\��
        this.pageTo(0);
    },
        
    pageUp: function(){

        //�y�[�W�����A�o���f�[�g
        ++this.page;
        this.page = this.page % dataController.getLength();
        
        //�\�����X�V
        this.updateView(this.page,this.push_trans,false);
    },
    
    pageDown: function(){
		
        //�y�[�W�����A�o���f�[�g
        --this.page;
        this.page = (this.page < 0) ? this.max_page : this.page % dataController.getLength();
        
        //�\�����X�V
        this.updateView(this.page,this.push_trans,true);
    },
    
    pageTo: function(n){        
        //�y�[�W����
        this.page = n % dataController.getLength();
        
        //�\�����X�V
        this.updateView(this.page,this.dissolve_trans,false);
    },
    
    updateView: function(pg,trans,isBack){
        var me = this;
        
        //define new view
        ++this.ct;
        var newViewId = "photoView" + this.ct % 2;
		var newPhoto = this["photo" + this.ct % 2];
        
        //define new image
        var temp_src = dataController.getImage(pg).src;
        
        //set background image
		newPhoto.load(temp_src);
        
        //start animation
        this.stackLayout.setCurrentViewWithTransition(newViewId,trans,isBack);
    }
    
}

var interfaceController = {
	init:function(){
		this.ct = 0;
		
		//init padView
		padViewController.init();
		
		//init lr buttons
		this.leftBtn = new VWButton("lBtn","img/left_btn.png","img/left_btn_hl.png",function(){imageViewController.pageDown();interfaceController.startTimer();});
		this.rightBtn = new VWButton("rBtn","img/right_btn.png","img/right_btn_hl.png",function(){imageViewController.pageUp();interfaceController.startTimer();});
		
		//init thumbnailController
		thumbnailController.init();
		
		//enable padView
		padViewController.enable(true);
	},
	
	showBtns: function(){
		this.leftBtn.appear();
		this.rightBtn.appear();
		thumbnailController.appear();
		this.startTimer();
		//
		padViewController.enableSwipe(false);
	},
	
	hideBtns: function(){
		//clear timer
		this.clearTimer();
		this.leftBtn.disappear();
		this.rightBtn.disappear();
		thumbnailController.disappear();
		//
		padViewController.enableSwipe(true);
	},
	
	startTimer:function(){
		var me = this;
		//clear timer
		this.clearTimer();
		//start timer
		this.timer = setTimeout(function(){
			me.hideBtns();
			++ me.ct;
		},2000);
	},
	
	clearTimer:function(){
		clearTimeout(this.timer);
	},
	
	toggle:function(){
		var n = this.ct % 2;
		switch(n){
			case 0:
				this.showBtns();
			break;
			case 1:
				this.hideBtns();
			break;
		}
		
		//count up
		++ this.ct;
	}
}


var padViewController = {
	init: function(){
		this.element = document.getElementById("pad");
	},
	
	enable: function(b){
		switch(b){
			case true:
				this.element.addEventListener("touchstart", this.touchStartHandler,false);
				this.element.addEventListener("touchend", this.touchEndHandler, false);
				this.element.addEventListener("touchcanceled",this.touchCanceledHandler,false);
				this.enableSwipe(true);
			break;
			case false:
				this.element.removeEventListener("touchstart", this.touchStartHandler,false);
				this.element.removeEventListener("touchend", this.touchEndHandler, false);
				this.element.removeEventListener("touchcanceled",this.touchCanceledHandler,false);
				this.enableSwipe(false);
			break;
		}
	},
	
	enableSwipe: function(b){
		switch(b){
			case true:
				this.element.addEventListener("touchmove", this.touchMoveHandler, false);
			break;
			case false:
				this.element.removeEventListener("touchmove", this.touchMoveHandler, false);
			break;
		}
	},
	
	touchStartHandler: function(e){
		
		//prevent window scroll
		e.preventDefault();
			
		//prevent gesture
		if (e.targetTouches.length > 1){
			e.stopPropagation();
			return false;
		}
			
		//init values
		padViewController.isTouchMove = false;
		padViewController.xDelta = 0;
		    	
		//memorize touchstart x
		padViewController.touchstartX = e.targetTouches[0].clientX;
	
		e.stopPropagation();
		
	},
	
	touchMoveHandler: function(e){
		
		//prevent window scroll
		e.preventDefault();
		
		//prevent gesture
		if (e.targetTouches.length > 1){
			e.stopPropagation();
			return false;
		}
		
	    padViewController.isTouchMove = true;
		var oldTouchstartX = padViewController.touchstartX;
		
		//memorize touchstart X
		padViewController.touchstartX = e.targetTouches[0].clientX;
	
		//calculate X delta
		var currentXDelta = padViewController.touchstartX - oldTouchstartX;
		padViewController.xDelta += currentXDelta;
		
		e.stopPropagation();
	},
	
	touchEndHandler: function(e){
		
		//prevent window scroll
		e.preventDefault();
		
		//prevent gesture
		if (e.targetTouches.length > 0){
			e.stopPropagation();
			return false;
		}
		
		//tapped----
		if (padViewController.isTouchMove == false) {
			interfaceController.toggle();
			e.stopPropagation();
			return false;
		};
		
		//swiped----
		if (padViewController.xDelta < -20){
			imageViewController.pageUp();
		}
		if (padViewController.xDelta > 20){
			imageViewController.pageDown();
		}
		
		padViewController.isTouchMove = false;
		
		e.stopPropagation();
		return false;
	},
	
	touchCanceledHandler: function(e){
		padViewController.isTouchMove = false;
		padViewController.xDelta = 0;
	}
}

var thumbnailController = {
	init:function(){
		//get element
		this.element = document.getElementById("thumbnailListView");
		this.element.style.webkitTransform = "translate(0px,98px)";
		
		//define transtion setting
		this.EASING_TIME = "0.3s";
		
		//init thumbnails
		this.thumbArray = new Array();
		this.setupThumbnails();
		
		//init tableViewController
		thumbnailTableController.init();
	},
	
	setupThumbnails:function(){
		var len = dataController.getLength();
		var tableTr = document.getElementById("thumb-tr");
				
		for (var i=0;i<len;i++){
			this.thumbArray[i] = new Thumbnail(i);
			tableTr.appendChild(this.thumbArray[i].td);
		}
	},
	
	appear:function(){
		this.element.style.webkitTransitionDuration = this.EASING_TIME;
        this.element.style.webkitTransform = "translate(0px,0px)";
		this.enableThumbnails(true);
		thumbnailTableController.enable(true);
	},
	
	disappear:function(){
		this.element.style.webkitTransitionDuration = this.EASING_TIME;
		this.element.style.webkitTransform = "translate(0px,98px)";
		this.enableThumbnails(false);
		thumbnailTableController.enable(false);
	},
	
	enableThumbnails:function(b){
		switch(b){
			case true:
				for (var i=0; i<this.thumbArray.length; i++){
					this.thumbArray[i].enable(true);
				}
				
			break;
			case false:
				for (var i=0; i < this.thumbArray.length; i++){
					this.thumbArray[i].enable(false);
				}
			break;
		}
	}
}

function Thumbnail(n){
	this.id = n;
	this.init();
}

Thumbnail.prototype.init = function(){
	//create img element
	this.img = new Image(50,50);
	this.img.src = dataController.getImages()[this.id].tmb;
	this.img.style.webkitBorderRadius = "5px";
	this.img.id = "thumb" + this.id;
	this.img.object = this;
	
	//create td element
	this.td = document.createElement("td");
	this.td.width = "50px";
	this.td.height = "50px";
	this.td.style.paddingRight = "50px";
	this.td.style.lineHeight = "1px";
			
	this.td.appendChild(this.img);
}

Thumbnail.prototype.enable = function(b){
	switch (b){
		case true:
			this.img.addEventListener("touchend",this.touchEndHandler,false);
		break;
		case false:
			this.img.removeEventListener("touchend",this.touchEndHandler,false);
		break;
	}
}

Thumbnail.prototype.touchEndHandler = function(e){
	if (thumbnailTableController.isTouchMove != true){
		imageViewController.pageTo(this.object.id);
	}
}



var thumbnailTableController = {
	init:function(){
		var me = this;
		
		this._x = 0;
		this.speed = 0;
		this.isTouchMove = false;
		
		this.element = document.getElementById("thumb-table");
		this.field = document.getElementById("thumbnailField");
		
		this.FRAMERATE = 60;
		this.FRICTION = 0.8;
		
		//fit to size
		this.updateEnvironment();
		
		//adapt to orientation change
	    //window.addEventListener("orientationchange",function(e){me.updateEnvironment(e);},false);-----
		orientationChangeDispatcher.addEventListener("orientationchange",function(e){me.updateEnvironment(e);},false);
		
		//start polling
		setInterval(function(){me.updateView();},1000 / this.FRAMERATE);
	},
	
	updateEnvironment:function(){
    	var field_w = this.field.offsetWidth;
    	var my_w = this.element.scrollWidth;
		
		this.minX = field_w - my_w;
	},
    
    set x(val){
        this._x = val;
        this.element.style.webkitTransform = "translateX("+val+"px)";
    },
	
    get x(){
        return this._x;
    },
	
	updateView:function(){
		
		var tx = this.x;
		
		//if x beyond the range, incresing speed to bring x back to the limit
		if (tx > 0){
			// ���[�𒴂����Ƃ�
			this.speed = 0.2 * (0 - tx);
		} else if (tx < this.minX){
			// �E�[�𒴂����Ƃ�
			this.speed = 0.2 * (this.minX - tx);
		} else {
			// �ʏ�
			this.speed *= this.FRICTION;
		}
    	
    	tx += this.speed;
    	this.x = tx;
	},
	
	enable:function(b){
		switch(b){
			case true:
				this.field.addEventListener("touchstart", this.touchStartHandler, false);
				this.field.addEventListener("touchmove", this.touchMoveHandler, false);
				this.field.addEventListener("touchend", this.touchEndHandler, false);
				this.field.addEventListener("touchcanceled", this.touchCanceledHandler, false);
			break;
			case false:
				this.field.removeEventListener("touchstart", this.touchStartHandler, false);
				this.field.removeEventListener("touchmove", this.touchMoveHandler, false);
				this.field.removeEventListener("touchend", this.touchEndHandler, false);
				this.field.removeEventListener("touchcanceled", this.touchCanceledHandler, false);
			break;
		}
	},
	
	touchStartHandler:function(e){
		
		//prevent hiding Btns
		interfaceController.clearTimer();
		
		//prevent window scroll
    	e.preventDefault();
		
		//prevent gesture
		if (e.targetTouches.length > 1){
			e.stopPropagation();
			return false;
		}
    		
		//init values
    	thumbnailTableController.isTouchMove = false;
		thumbnailTableController.xDelta = 0;
		thumbnailTableController.timeDelta = 0;
        	
		//memorize touchstart x and time
    	thumbnailTableController.touchstartX = e.targetTouches[0].clientX;
   		thumbnailTableController.touchstartTime = new Date().getTime();
    
    	thumbnailTableController.speed = 0;
		
		e.stopPropagation();
	},
	
	touchMoveHandler:function(e){		
		//prevent hiding Btns
		interfaceController.clearTimer();
		
		//prevent window scroll
		e.preventDefault();
        
		//prevent gesture
		if (e.targetTouches.length > 1){return false;}
		
        thumbnailTableController.isTouchMove = true;
		var oldTouchstartX = thumbnailTableController.touchstartX;
		var oldTouchstartTime = thumbnailTableController.touchstartTime;
    	
		//memorize touchstart X and Time
		thumbnailTableController.touchstartX = e.targetTouches[0].clientX;
		thumbnailTableController.touchtartTime = new Date().getTime();
    
		//calculate X delta
		var currentXDelta = thumbnailTableController.touchstartX - oldTouchstartX;
		thumbnailTableController.xDelta += currentXDelta;
		
		//calculate Time delta
		thumbnailTableController.touchstartTime = (new Date()).getTime();
		var currentTimeDelta = (thumbnailTableController.touchstartTime - oldTouchstartTime) / thumbnailTableController.FRAMERATE;
    	thumbnailTableController.timeDelta += currentTimeDelta;
		
		//update x
		thumbnailTableController.x += currentXDelta;
},
	
	touchEndHandler:function(e){
		
		//start hiding timer
		interfaceController.startTimer();
		
		//prevent window scroll
		e.preventDefault();
        
		//prevent gesture
    	if (e.targetTouches.length > 0){
			return false;
		}
		
		//prevent just touch
		if (thumbnailTableController.isTouchMove == false) {return false};
		
		//calculate Time delta
		var oldTouchstartTime = thumbnailTableController.touchstartTime;
		thumbnailTableController.touchstartTime = (new Date()).getTime();
		var currentTimeDelta = (thumbnailTableController.touchstartTime - oldTouchstartTime) / thumbnailTableController.FRAMERATE;
    	thumbnailTableController.timeDelta += currentTimeDelta;
		    
		//calculate speed
    	var spd = thumbnailTableController.xDelta / thumbnailTableController.timeDelta;
    	spd = (isFinite(spd)) ? spd : 0;
		
		//alert(spd);
    
    	thumbnailTableController.speed = spd;
		
		thumbnailTableController.isTouchMove = false;
		
	},
	
	touchCanceledHandler:function(e){
		//start hiding timer
		interfaceController.startTimer();
		
		//prevent window scroll
		e.preventDefault();
    
		//thumbnailTableController.isTouch = false;
		thumbnailTableController.isTouchMove = false;
	}
	
	
}
