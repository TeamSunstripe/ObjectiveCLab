/**
 * @author os
 * ver0.2 changed for implementation @1020
 */

 function Photo(id,parent,depth) {
 	this._id = id;
 	this._parent = document.getElementById(parent); 
	this._depth = depth;
	this.originalWidth = 0;
	this.originalHeight = 0;
	
	this.setup();
 }
 
 Photo.prototype.setup = function(){
 	//create Image
 	this._img = new Image();
	
	//set attributes
	this._img.style.position = "absolute";
	this._img.style.zIndex = this._depth;
	
	//call onResize method when orientation change
	var me = this;
	//window.addEventListener("orientationchange",function(){me.onResized();},false);--------
	orientationChangeDispatcher.addEventListener("orientationchange",function(){me.onResized();},false);
	
	//append
 	this.element = this._parent.appendChild(this._img);
	this.element.id = this._id;
	
	//animation setting
	this.element.style.webkitTransformOrigin = "50% 50%";
	this.element.style.webkitTransition =  "all 0.3s ease-out";

}
 
 Photo.prototype.load = function(src){
 	//reset
 	delete this._img.onload;
	this._img.src = "";
	
 	//set onload handler
 	var me = this;
	this._img.onload = function(){me.didLoad();}
	
	this.element.style.webkitTransition =  "all 0s linear";
	this.element.style.opacity = 0;
	
	//start loading
 	this._img.src = src;	
}
 
Photo.prototype.didLoad = function(){
	//set original size
 	this.originalWidth = this._img.naturalWidth;
	this.originalHeight = this._img.naturalHeight;
	
	var m = this.getMag();
	this.currentMag = m.fitMag;
		
	//�����l��10%�̑傫���ɂ��ăZ���^�[�ɔz�u
	this.element.style.webkitTransform = m.translateToCenter + " " + "scale3d(" + (m.fitMag * 0.1) + "," + (m.fitMag * 0.1) + ",1)";
	this.element.style.opacity = 0.5;
	
	//start animation
	var me = this;
	setTimeout(function(){
		me.element.style.webkitTransition = "all 0.3s ease-out";
		me.element.style.opacity = 1;
		me.element.style.webkitTransform =  m.translateToCenter + " " + m.fitScale;
	},10);
}
 

 Photo.prototype.onResized = function(){
 	var me = this;
 	var m = this.getMag();
	
	var oldScale = "scale3d(" + this.currentMag + "," + this.currentMag + ",1)";
	
	this.currentMag = m.fitMag;
	
	this.element.style.webkitTransition = "all 0.2s ease-out";
	this.element.style.webkitTransform = m.translateToCenter + " " + oldScale;
		
	this.animeTimer = setTimeout(function(){
		me.element.style.webkitTransition =  "all 0.3s ease-out";
		me.element.style.webkitTransform = m.translateToCenter + " "+ m.fitScale;
	},210);

 }
 
 Photo.prototype.getMag = function(){
 	var retObj = new Object();
	
 	var w = window.innerWidth;
	var h = window.innerHeight;
	
	var wMag = w / this.originalWidth;
	var hMag = h / this.originalHeight;
	
	retObj.fitMag = Math.min(wMag,hMag);
	retObj.fillMag = Math.max(wMag,hMag);
		
	//scale
	retObj.fitScale = "scale3d(" + retObj.fitMag + "," + retObj.fitMag + ",1)";
	retObj.fillScale = "scale3d(" + retObj.fillMag + "," + retObj.fillMag + ",1)";
	
	//translate
	retObj.translateToCenter = "translate3d(" + ((w - this.originalWidth) / 2) + "px," + ((h - this.originalHeight) / 2) + "px,100%)";
	
	return retObj;
 }
 
