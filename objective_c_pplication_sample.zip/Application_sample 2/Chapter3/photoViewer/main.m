//
//  main.m
//  WebPhotoViewer
//
//  Created by Yosuke Suzuki on 10/11/29.
//  Copyright 2010 バスケ. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
