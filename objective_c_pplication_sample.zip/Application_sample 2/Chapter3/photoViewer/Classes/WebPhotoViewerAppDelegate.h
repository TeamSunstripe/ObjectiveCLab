//
//  WebPhotoViewerAppDelegate.h
//  WebPhotoViewer
//
//  Created by Yosuke Suzuki on 10/11/29.
//  Copyright 2010 バスケ. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HTMLViewController;

@interface WebPhotoViewerAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    HTMLViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet HTMLViewController *viewController;

@end

