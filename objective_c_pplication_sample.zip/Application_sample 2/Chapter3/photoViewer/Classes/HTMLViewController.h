//
//  WebPhotoViewerViewController.h
//  WebPhotoViewer
//
//  Created by Yosuke Suzuki on 10/11/29.
//  Copyright 2010 バスケ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HTMLViewController : UIViewController<UIWebViewDelegate> {
}

+ (id)controllerWithResourcePath:(NSString *)path;
+ (id)controllerWithResourcePath:(NSString *)path nibNamed:(NSString *)nib bundle:(NSBundle *)bundle;

- (id)initWithResourcePath:(NSString *)path nibNamed:(NSString *)nib bundle:(NSBundle *)bundle;

@property(nonatomic, retain) IBOutlet UIWebView *webView;
@property(nonatomic, retain) NSString *path;

@end

