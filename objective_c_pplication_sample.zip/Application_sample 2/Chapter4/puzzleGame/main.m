//
//  main.m
//  puzzleGame
//
//  Created by 溝田 隆明 on 10/12/27.
//  Copyright 2010 conol. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
