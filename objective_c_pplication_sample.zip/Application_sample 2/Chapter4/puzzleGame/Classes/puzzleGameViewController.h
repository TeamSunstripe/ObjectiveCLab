//
//  puzzleGameViewController.h
//  puzzleGame
//
//  Created by 溝田 隆明 on 10/12/27.
//  Copyright 2010 conol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface puzzleGameViewController : UIViewController<UIWebViewDelegate> {
    UIWebView *_webview;
}
@property (nonatomic, retain) IBOutlet UIWebView *webview;
@property (nonatomic, copy) IBOutlet NSString *path;

+ (id)controllerWithResourcePath:(NSString *)path;
+ (id)controllerWithResourcePath:(NSString *)path nibNamed:(NSString *)nib bundle:(NSBundle *)bundle;

- (id)initWithResourcePath:(NSString *)path nibNamed:(NSString *)nib bundle:(NSBundle *)bundle;


@end