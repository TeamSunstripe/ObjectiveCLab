//
//  puzzleGameViewController.m
//  puzzleGame
//
//  Created by 溝田 隆明 on 10/12/20.
//  Copyright 2010 conol. All rights reserved.
//
#import "puzzleGameViewController.h"

#define DEFAULT_HTML @"html/index.html"

@implementation puzzleGameViewController

+ (id)controllerWithResourcePath:(NSString *)path {
	return [[self class] controllerWithResourcePath:path nibNamed:nil bundle:nil];
}

+ (id)controllerWithResourcePath:(NSString *)path nibNamed:(NSString *)nib bundle:(NSBundle *)bundle {
	return [[[puzzleGameViewController alloc] initWithResourcePath:path nibNamed:nib bundle:bundle] autorelease];
}


@synthesize webview = webview_;
@synthesize path=path_;


- (id)initWithResourcePath:(NSString *)path nibNamed:(NSString *)nib bundle:(NSBundle *)bundle {
	if (self = [super initWithNibName:nib bundle:bundle]) {
		self.path = path;
	}
	return self;
}

- (void)viewDidLoad {
	NSString *path = self.path;
	if ([path length] == 0) {
		path = DEFAULT_HTML;
	}
	[self.navigationController setNavigationBarHidden:NO animated:YES];
	
	NSString *ext	= [path pathExtension];
	NSURL *url		= [[NSBundle mainBundle] URLForResource:[path stringByDeletingPathExtension] withExtension:ext];
	NSURLRequest *request = [NSURLRequest requestWithURL:url];
	[self.webview loadRequest:request];

}

- (void)viewWillAppear:(BOOL)animated {
	NSString *path = self.path;
	if ([path length] == 0) {
		[self.navigationController setNavigationBarHidden:YES animated:YES];
	}
}

-(void) viewDidAppear:(BOOL)animated {
	NSString* title = [self.webview stringByEvaluatingJavaScriptFromString:@"document.title"];
	if ([title length] == 0) {
		title = @"スタート画面";
	}
	self.navigationItem.title = title;
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
	NSRange range = [[[request URL] absoluteString] rangeOfString:@"www.gakken.jp" options:NSCaseInsensitiveSearch];
	if(navigationType == UIWebViewNavigationTypeLinkClicked){
		if (range.location != NSNotFound) {
			UIApplication *app	= [UIApplication sharedApplication];
			NSURL *url			= [NSURL URLWithString:[[request URL] absoluteString]];
			
			if ([app canOpenURL:url]) {
				[app openURL:url];
				return NO;
			}
		}
		NSString *clickLink	= [[request URL] absoluteString];
		NSArray *sepalate	= [clickLink componentsSeparatedByString:@"/"];
		int cnt = [sepalate count];
		puzzleGameViewController *jump = [[self class] controllerWithResourcePath:[NSString stringWithFormat:@"html/%@",[sepalate objectAtIndex:cnt-1]]];
		[self.navigationController pushViewController:jump animated:YES];
		return NO;
	}
	return YES;
}

- (void)viewDidUnload {
	self.webview = nil;
	
	[super viewDidUnload];
}

- (void)dealloc {
	self.path = nil;
	self.webview = nil;
	
	[super dealloc];
}

@end