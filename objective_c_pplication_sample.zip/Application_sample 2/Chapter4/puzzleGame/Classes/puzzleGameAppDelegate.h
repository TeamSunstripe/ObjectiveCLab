//
//  puzzleGameAppDelegate.h
//  puzzleGame
//
//  Created by 溝田 隆明 on 10/12/27.
//  Copyright 2010 conol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface puzzleGameAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    UINavigationController *naviController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *naviController;

@end

