// 全面赤の背景色指定
var window = Titanium.UI.createWindow({
   backgroundColor:'#FFFFFF'
});

var flexSpace = Titanium.UI.createButton({
        systemButton:Titanium.UI.iPhone.SystemButton.FLEXIBLE_SPACE
});

var camera = Titanium.UI.createButton({
        backgroundImage:'images/camera.png',
        height:40,
        width:100,
		top:200
});
camera.addEventListener('click', function(){
	//Titanium.UI.createAlertDialog({title:'Toolbar',message:'You clicked camera!'}).show();
	Titanium.Media.showCamera({
    	// JSON形式の引数です
    	success:function(event){
        	// cropRectにはx,y,height,widthといったデータがはいる。
        	var cropRect = event.cropRect;
        	var image    = event.media;

        	// 撮影されたデータが写真ならばImageViewとしてWindowに貼り付ける
        	if(event.mediaType == Ti.Media.MEDIA_TYPE_PHOTO){
            	var imageView = Ti.UI.createImageView({
            	    width:window.width,
            	    height:window.height,
            	    image:event.media
            	});
            	window.add(imageView);  
        	}
    	},
    	cancel:function(){
    	    // ...
    	},
    	error:function(error){
    	    // errorとしてカメラがデバイスにないようなケース(iPod touchなどがそうでしょうか)では
			// error.code が Titanium.Media.NO_CAMERA として返ります。
	},
    // 撮影データのフォトギャラリーへの保存
    saveToPhotoGallery:true,
    // 撮影直後に拡大縮小移動をするか否かのフラグ
    allowEditing:true,
    // 撮影可能なメディア種別を配列で指定
    mediaTypes:[Ti.Media.MEDIA_TYPE_VIDEO,Ti.Media.MEDIA_TYPE_PHOTO],

    });

});

// Windowの下部にツールバーを設定する。
/*var toolbar1 = Titanium.UI.createToolbar({
        items:[flexSpace,camera,flexSpace],
        top:416,
        borderTop:false,
        borderBottom:true,
      //  barColor:'#333'
});
window.add(toolbar1);*/

window.add(camera);

window.open({
    animated:true
});

