//
//  nimble_sampleAppDelegate.h
//  nimble_sample
//
//  Created by 溝田 隆明 on 11/02/13.
//  Copyright conol 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface nimble_sampleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

