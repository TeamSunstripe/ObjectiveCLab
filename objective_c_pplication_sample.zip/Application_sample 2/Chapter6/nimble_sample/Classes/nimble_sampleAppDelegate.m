//
//  nimble_sampleAppDelegate.m
//  nimble_sample
//
//  Created by 溝田 隆明 on 11/02/13.
//  Copyright conol 2011. All rights reserved.
//

#import "nimble_sampleAppDelegate.h"
#import "Nimble.h"
#import "NKBridge.h"

extern BOOL _mainWebViewLoaded;

@implementation nimble_sampleAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    

	Nimble *nimble = [[Nimble alloc] initWithRootPage:@"main.html" window:window serial:@""];
	[nimble release];
	[window makeKeyAndVisible];
	while (!_mainWebViewLoaded) {
		[[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:1]];
	}	
}

- (void)applicationWillTerminate:(UIApplication *)application
{
	[[NKBridge sharedInstance] performSelector:@selector(onApplicationQuit)];
}

- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
